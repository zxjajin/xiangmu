function addCart(bookId){
    window.location.href='cart.do?operate=addCart&bookId='+bookId;
}