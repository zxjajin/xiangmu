package com.atguigu.myssm.basedao;

/**
 * @author ajin
 * @create 2022-09-11 1:39
 */
public class DAOException extends RuntimeException{
    public  DAOException(String msg){
        super(msg);
    }
}
