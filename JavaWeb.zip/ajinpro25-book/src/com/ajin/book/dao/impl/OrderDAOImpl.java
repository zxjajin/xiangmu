package com.ajin.book.dao.impl;

import com.ajin.book.dao.OrderDAO;
import com.ajin.book.pojo.OrderBean;
import com.atguigu.myssm.basedao.BaseDAO;

/**
 * @author ajin
 * @create 2022-09-25 21:19
 */
public class OrderDAOImpl extends BaseDAO<OrderBean> implements OrderDAO {
    @Override
    public void addOrderBean(OrderBean orderBean) {
        int orderBeanId = super.executeUpdate("insert into t_order values(0,?,?,?,?,?)",orderBean.getOrderNo(),orderBean.getOrderDate(),orderBean.getOrderUser().getId(),orderBean.getOrderMoney(),orderBean.getOrderStatus());
        orderBean.setId(orderBeanId);
        //思考：此处为什么需要接收executeUpdate的返回值，然后设置到OrderBean中的id属性上？
    }
}
