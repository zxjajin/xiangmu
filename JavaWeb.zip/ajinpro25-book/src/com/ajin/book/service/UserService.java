package com.ajin.book.service;

import com.ajin.book.pojo.User;

/**
 * @author ajin
 * @create 2022-09-23 16:38
 */
public interface UserService {
    User login(String uname,String pwd);
}
