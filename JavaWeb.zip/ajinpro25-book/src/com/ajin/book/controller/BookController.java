package com.ajin.book.controller;

import com.ajin.book.pojo.Book;
import com.ajin.book.service.BookService;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 17:44
 */
public class BookController {

    private BookService bookService;
    public String index(HttpSession session){
        List<Book>  bookList = bookService.getBookList();
        session.setAttribute("bookList",bookList);
        return "index";

    }
}
