package com.atguigu.myssm.myspringmvc;

/**
 * @author ajin
 * @create 2022-09-11 2:05
 */
public class DispatcherServletException extends RuntimeException{
    public DispatcherServletException(String msg){
        super(msg);
    }
}
