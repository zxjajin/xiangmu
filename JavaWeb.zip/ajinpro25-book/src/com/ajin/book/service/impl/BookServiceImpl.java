package com.ajin.book.service.impl;

import com.ajin.book.dao.BookDAO;
import com.ajin.book.pojo.Book;
import com.ajin.book.service.BookService;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 17:34
 */
public class BookServiceImpl implements BookService {
    private BookDAO bookDAO;

    @Override
    public List<Book> getBookList() {
        return bookDAO.getBookList();
    }

    @Override
    public Book getBook(Integer id) {
        return bookDAO.getBook(id);
    }
}
