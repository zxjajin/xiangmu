package com.atguigu.myssm.filters;


import com.atguigu.myssm.trans.TransactionManager;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.sql.SQLException;

/**
 * @author ajin
 * @create 2022-09-08 23:33
 */
@WebFilter("*.do")
public class OperSessionInViewFilter implements Filter {

    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain){
        try {
            TransactionManager.beginTrans();
            System.out.println("开始事务...");
            filterChain.doFilter(servletRequest,servletResponse);
            TransactionManager.commint();
            System.out.println("提交事务...");
        } catch (Exception e) {
            e.printStackTrace();
            try {
                TransactionManager.rollback();
                System.out.println("回滚事务");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void destroy() {

    }
}
