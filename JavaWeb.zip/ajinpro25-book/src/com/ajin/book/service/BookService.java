package com.ajin.book.service;

import com.ajin.book.pojo.Book;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 17:33
 */
public interface BookService {
    List<Book> getBookList();
    Book getBook(Integer id);
}
