package com.ajin.book.dao;

import com.ajin.book.pojo.OrderBean;

/**
 * @author ajin
 * @create 2022-09-25 17:38
 */
public interface OrderDAO {
    //添加订单
    void addOrderBean(OrderBean orderBean);

}
