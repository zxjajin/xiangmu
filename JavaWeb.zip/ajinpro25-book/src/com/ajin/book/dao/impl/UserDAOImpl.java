package com.ajin.book.dao.impl;

import com.ajin.book.dao.UserDAO;
import com.ajin.book.pojo.User;
import com.atguigu.myssm.basedao.BaseDAO;

/**
 * @author ajin
 * @create 2022-09-23 16:31
 */
public class UserDAOImpl extends BaseDAO<User> implements UserDAO {

    @Override
    public User getUser(String uname, String pwd) {
        return super.load("select * from t_user where uname = ? and pwd = ?",uname,pwd);
    }
}
