package com.atguigu.qqzone.dao;

/**
 * @author ajin
 * @create 2022-09-14 19:55
 */
public interface HostReplyDAO {

}
