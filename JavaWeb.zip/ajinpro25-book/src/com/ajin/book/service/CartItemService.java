package com.ajin.book.service;

import com.ajin.book.pojo.Cart;
import com.ajin.book.pojo.CartItem;
import com.ajin.book.pojo.User;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-24 19:47
 */
public interface CartItemService {
    void addCartItem(CartItem cartItem);
    void updateCartItem(CartItem cartItem);
    void addOrUpdateItem(CartItem cartItem, Cart cart);

    //获取指定用户的所有项列表(需要注意的是，这个方法内部查询的时候，会将book的详细信息设置进去)
    List<CartItem> getCartItemList(User user);

    //加载特定用户的购物车信息
    Cart getCart(User user);
}
