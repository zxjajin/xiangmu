package com.ajin.book.dao;

import com.ajin.book.pojo.CartItem;
import com.ajin.book.pojo.User;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-24 15:44
 */
public interface CartItemDAO {
    //新增购物车项
    void addCartItem(CartItem cartItem);
    //修改特定的购物车项
    void updateCartItem(CartItem cartItem);
    //获取特定用户的所有购物车项
    List<CartItem> getCartItemList(User user);
    //删除特定的购物车项
    void delCartItem(CartItem cartItem);
}
