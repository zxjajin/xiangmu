package com.ajin.book.dao;

import com.ajin.book.pojo.User;

/**
 * @author ajin
 * @create 2022-09-23 16:30
 */
public interface UserDAO {
    User getUser(String uname,String pwd);
}
