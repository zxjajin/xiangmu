package com.ajin.book.dao.impl;

import com.ajin.book.dao.BookDAO;
import com.ajin.book.pojo.Book;
import com.atguigu.myssm.basedao.BaseDAO;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 17:32
 */
public class BookDAOImpl extends BaseDAO<Book> implements BookDAO {
    @Override
    public List<Book> getBookList() {
        return executeQuery("select * from t_book where bookStatus = 0");
    }

    @Override
    public Book getBook(Integer id) {
        return load("select * from t_book where id = ?",id);
    }
}
