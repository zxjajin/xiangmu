package com.atguigu.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author ajin
 * @create 2022-09-05 23:10
 */
//@WebServlet(urlPatterns = {"/demo01"},
//        initParams = {
//        @WebInitParam(name = "hello",value = "world"),
//        @WebInitParam(name = "uname",value = "ajin")
//        }
//        )
public class Demo01Servlet  extends HttpServlet {
    @Override
    public void init() throws ServletException {
        ServletConfig config = getServletConfig();
        String initValue = config.getInitParameter("hello");
        System.out.println("initValue = " + initValue);
        String uname = config.getInitParameter("uname");
        System.out.println("uname = " + uname);
        ServletContext context = getServletContext();
        String contextConfigLocation = context.getInitParameter("contextConfigLocation");
        System.out.println("contextConfigLocation = " + contextConfigLocation);
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        req.getServletContext();
        req.getSession().getServletContext();
    }
}


//Servlet生命周期：实例化、初始化、服务、销毁
