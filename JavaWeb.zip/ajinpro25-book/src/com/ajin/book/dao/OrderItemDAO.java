package com.ajin.book.dao;

import com.ajin.book.pojo.OrderItem;

/**
 * @author ajin
 * @create 2022-09-25 17:40
 */
public interface OrderItemDAO {
    //添加订单项
    void addOrderItem(OrderItem orderItem);
}
