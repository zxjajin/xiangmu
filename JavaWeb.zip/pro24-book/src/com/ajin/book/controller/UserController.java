package com.ajin.book.controller;

import com.ajin.book.pojo.User;
import com.ajin.book.service.UserService;

/**
 * @author ajin
 * @create 2022-09-23 16:27
 */
public class UserController {
    UserService userService;
    public String login(String uname,String pwd){
        User user = userService.login(uname, pwd);

        System.out.println(user);
        return "index";
    }
}
