package com.atguigu.myssm.myspringmvc;

/**
 * @author ajin
 * @create 2022-09-15 21:24
 */
public class PageController {
    public String page(String page){
        return page;        //frames/left
    }
}
