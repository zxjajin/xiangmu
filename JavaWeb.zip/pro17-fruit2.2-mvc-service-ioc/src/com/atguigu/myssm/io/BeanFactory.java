package com.atguigu.myssm.io;

/**
 * @author ajin
 * @create 2022-09-06 16:45
 */
public interface BeanFactory {
    Object getBean(String id);
}
