package com.ajin.book.service.impl;

import com.ajin.book.dao.UserDAO;
import com.ajin.book.pojo.User;

/**
 * @author ajin
 * @create 2022-09-23 16:39
 */
public class UserServiceImpl implements com.ajin.book.service.UserService {
    private UserDAO userDAO;
    @Override
    public User login(String uname, String pwd) {
        return userDAO.getUser(uname,pwd);
    }
}
