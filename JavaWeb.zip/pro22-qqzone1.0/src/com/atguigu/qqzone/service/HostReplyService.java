package com.atguigu.qqzone.service;

import com.atguigu.qqzone.pojo.HostReply;

/**
 * @author ajin
 * @create 2022-09-18 23:57
 */
public interface HostReplyService {
    HostReply getHostReplyByRelyId(Integer replyId);
    void delHostReply(Integer id);
}
