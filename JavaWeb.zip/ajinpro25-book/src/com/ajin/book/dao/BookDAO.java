package com.ajin.book.dao;

import com.ajin.book.pojo.Book;

import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 17:23
 */
public interface BookDAO {
//    List<Book> getBookList(Integer minPrice , Integer maxPrice , Integer pageNo);
    List<Book> getBookList();
    Book getBook(Integer id);
}
