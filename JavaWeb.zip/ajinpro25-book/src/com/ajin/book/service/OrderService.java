package com.ajin.book.service;

import com.ajin.book.pojo.OrderBean;

/**
 * @author ajin
 * @create 2022-09-25 21:35
 */
public interface OrderService {
    void addOrderBean(OrderBean orderBean);

}
