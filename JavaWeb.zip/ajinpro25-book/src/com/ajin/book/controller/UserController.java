package com.ajin.book.controller;

import com.ajin.book.dao.BookDAO;
import com.ajin.book.pojo.Book;
import com.ajin.book.pojo.Cart;
import com.ajin.book.pojo.User;
import com.ajin.book.service.BookService;
import com.ajin.book.service.CartItemService;
import com.ajin.book.service.UserService;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @author ajin
 * @create 2022-09-23 16:27
 */
public class UserController {
    private UserService userService;
    private CartItemService cartItemService;

    public String login(String uname,String pwd , HttpSession session){

        User user = userService.login(uname, pwd);

        if (user!=null){
            Cart cart = cartItemService.getCart(user);
            user.setCart(cart);

            session.setAttribute("currUser",user);
            return "redirect:book.do";
        }
        return "user/login";
    }
}
