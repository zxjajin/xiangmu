
//当鼠标悬浮时，显示背景颜色
function showBGColor() {
  //event:当前发生的事件
  //event.srcElement:事件源
  // alert(event.srcElement);
  // alert(event.srcElement.tagName); --> TD
  if (event && event.srcElement && event.srcElement.tagName == "TD") {
    var td = event.srcElement;
    //td.parentElement 表示获取td的父元素 -> TR
    var tr = td.parentElement;
    tr.style.backgroundColor = "navy";
    //tr.cells表示获取这个tr中所有的单元格
    var tds = tr.cells;
    for (var i = 0; i < tds.length; i++) {
      tds[i].style.color = "white";
    }

  }
}
  //当鼠标离开时，恢复原始样式
  function clearBGColor(){
    if (event && event.srcElement && event.srcElement.tagName=="TD"){
      var td = event.srcElement;
      var tr = td.parentElement;
      tr.style.backgroundColor = "transparent";
      var tds = tr.cells;
      for (var i = 0; i < tds.length; i++) {
            tds[i].style.color = "blue";
      }
    }
  }
function showHand(){
  if (event && event.srcElement && event.srcElement.tagName=="TD"){
    var td = event.srcElement;
    //cusor : 光标
    td.style.cursor="hand";
  }
}
